
# Web (GitHub Pages) output
- Publish `web/public` as GitHub Pages (root or `/docs` if you prefer).
- The iOS app will fetch `539_stats.json` from your GitHub Pages URL.
